"use strict";
exports.id = 877;
exports.ids = [877];
exports.modules = {

/***/ 5877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

axios__WEBPACK_IMPORTED_MODULE_0___default().interceptors.request.use(function(config) {
    config.baseURL = "http://localhost:8000/api/";
    return config;
}, function(error) {
    return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
    get: (axios__WEBPACK_IMPORTED_MODULE_0___default().get),
    post: (axios__WEBPACK_IMPORTED_MODULE_0___default().post),
    put: (axios__WEBPACK_IMPORTED_MODULE_0___default().put),
    delete: (axios__WEBPACK_IMPORTED_MODULE_0___default()["delete"]),
    patch: (axios__WEBPACK_IMPORTED_MODULE_0___default().patch)
});


/***/ })

};
;