(() => {
var exports = {};
exports.id = 696;
exports.ids = [696];
exports.modules = {

/***/ 2579:
/***/ ((module) => {

// Exports
module.exports = {
	"TableWrapper": "Table_TableWrapper__UwVqT",
	"Table__pagination": "Table_Table__pagination__KcZ6h",
	"Table__pagination-item": "Table_Table__pagination-item__lZBwE",
	"table__pagination-item": "Table_table__pagination-item__f7Rp5",
	"active": "Table_active__yip5o"
};


/***/ }),

/***/ 7561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Projects),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/axiosInstance/axios.js
var axios = __webpack_require__(5877);
// EXTERNAL MODULE: ./components/Header/Header.js
var Header = __webpack_require__(7797);
// EXTERNAL MODULE: ./components/Table/Table.module.css
var Table_module = __webpack_require__(2579);
var Table_module_default = /*#__PURE__*/__webpack_require__.n(Table_module);
;// CONCATENATED MODULE: ./components/Table/Pagination.js



function Pagination({ currentPage , next , prev  }) {
    const renderItem = (item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
            className: [
                "page-item",
                item == currentPage ? "active" : ""
            ].join(" "),
            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/projects/" + item,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    className: "page-link",
                    children: item
                })
            })
        }, item)
    ;
    let paginationItems = currentPage > 1 ? Array(+currentPage).fill(" ").map((_, index)=>renderItem(index + 1)
    ) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    return /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        "aria-label": "...",
        className: "d-flex justify-content-end mt-3",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "pagination",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: [
                        "page-item",
                        prev == null ? "disabled" : ""
                    ].join(" "),
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/projects/" + prev,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "page-link",
                            tabIndex: "-1",
                            children: "Previous"
                        })
                    })
                }),
                paginationItems,
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: [
                        "page-item",
                        next == null ? "disabled" : ""
                    ].join(" "),
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/projects/" + next,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "page-link",
                            children: "Next"
                        })
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/Table/Table.jsx




const Table = ({ headData , renderHead , bodyData , renderBody , currentPage , next , prev  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Table_module_default()).TableWrapper,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    children: [
                        headData && renderHead ? /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("tr", {
                                children: headData.map((item, index)=>renderHead(item, index)
                                )
                            })
                        }) : null,
                        bodyData && renderBody ? /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                            children: bodyData.map((item, index)=>renderBody(item, index)
                            )
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Pagination, {
                currentPage: currentPage,
                next: next,
                prev: prev
            })
        ]
    });
};
/* harmony default export */ const Table_Table = (Table);

// EXTERNAL MODULE: ./components/Modal/Modal.js
var Modal = __webpack_require__(6785);
;// CONCATENATED MODULE: ./pages/projects/[page].js








const PROJECTSLIMIT = 7;
function Projects({ projectsData , currentPage , nextPageUrl , prevPageUrl  }) {
    const { 0: isDeleted , 1: setIsDeleted  } = (0,external_react_.useState)(false);
    const { 0: message , 1: setMessage  } = (0,external_react_.useState)(false);
    const deleteHandler = (e, id)=>{
        disabledHandler();
        axios/* default.post */.Z.post(`/project/delete/${id}`).then((res)=>{
            setIsDeleted(true);
            setMessage("deleted successfully");
            e.target.parentElement.parentElement.remove();
            enabledHandler();
        }).catch((err)=>{
            setIsDeleted(false);
            setMessage("ooops! there is an error");
        });
    };
    const projectsTableHead = [
        "id",
        "project name",
        "date",
        "action", 
    ];
    const disabledHandler = ()=>{
        document.querySelectorAll(".btn-action").forEach((btn)=>{
            btn.classList.add("disabled");
        });
    };
    const enabledHandler = ()=>{
        document.querySelectorAll(".btn-action").forEach((btn)=>{
            btn.classList.remove("disabled");
        });
    };
    const renderHead = (item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("th", {
            children: item
        }, index)
    ;
    const renderBody = (item, index)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                    children: item.id
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                    children: JSON.parse(item.project_details)["project-name"]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                    children: item.created_at
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                    className: "d-flex align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `/projects/show/${item.id}`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "btn btn-outline-primary btn-action",
                                onClick: disabledHandler,
                                children: "Show"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "btn btn-outline-danger btn-action m-1",
                            onClick: (e)=>deleteHandler(e, item.id)
                            ,
                            children: "Delete"
                        })
                    ]
                })
            ]
        }, index);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "Projects"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card container mt-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-center main-color mb-3",
                        children: "Projects"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "card__body",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Table_Table, {
                            headData: projectsTableHead,
                            renderHead: (item, index)=>renderHead(item, index)
                            ,
                            bodyData: projectsData,
                            renderBody: (item, index)=>renderBody(item, index)
                            ,
                            limit: 2,
                            next: nextPageUrl !== null ? +currentPage + 1 : nextPageUrl,
                            prev: prevPageUrl !== null ? +currentPage - 1 : prevPageUrl,
                            currentPage: currentPage
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Modal/* default */.Z, {
                title: "delete project Status: ",
                show: isDeleted,
                hideHandler: ()=>setIsDeleted(false)
                ,
                message: message
            })
        ]
    });
};
async function getServerSideProps(context) {
    let response = await axios/* default.get */.Z.get("/project/all?per_page=" + PROJECTSLIMIT + "&page=" + context.params.page);
    return {
        props: {
            projectsData: response.data.data,
            prevPageUrl: response.data.prev_page_url,
            nextPageUrl: response.data.next_page_url,
            currentPage: context.params.page
        }
    };
}


/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,877,797,785], () => (__webpack_exec__(7561)));
module.exports = __webpack_exports__;

})();