exports.id = 519;
exports.ids = [519];
exports.modules = {

/***/ 3731:
/***/ ((module) => {

// Exports
module.exports = {
	"Sidebar": "Sidebar_Sidebar__O0cQk",
	"Close": "Sidebar_Close__nAYIr",
	"Open": "Sidebar_Open__GE1qn",
	"Sidebar_Logo": "Sidebar_Sidebar_Logo__pS0a5",
	"runLogo": "Sidebar_runLogo__I_vSC",
	"Sidebar_Item_Inner": "Sidebar_Sidebar_Item_Inner__JUV7J",
	"Active": "Sidebar_Active__pv2v2"
};


/***/ }),

/***/ 9519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Sidebar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3731);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(197);
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);








const SidebarItems = [
    {
        displayName: "dashbaord",
        route: "/",
        icon: _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_3__.faRectangleList
    },
    {
        displayName: "add projects",
        route: "/add-project",
        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faSquarePlus
    },
    {
        displayName: "projects",
        route: "/projects/1",
        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faProjectDiagram
    }, 
];
function Sidebar({ dashboardName  }) {
    const sidebarRef = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createRef)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const handleToggleSidebar = ()=>{
        sidebarRef.current.classList.toggle((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Close));
        sidebarRef.current.classList.toggle((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open));
        let sidebarWidth = getComputedStyle(document.documentElement).getPropertyValue("--sidebar-width").trim();
        document.documentElement.style.setProperty("--sidebar-width", sidebarWidth === "300px" ? "100px" : "300px");
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (sidebarRef && sidebarRef.current && sidebarRef.current.classList !== null) {
            if (window.innerWidth < 800) {
                sidebarRef.current.classList.add((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Close));
                sidebarRef.current.classList.remove((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open));
                document.documentElement.style.setProperty("--sidebar-width", "100px");
            } else {
                sidebarRef.current.classList.add((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open));
                sidebarRef.current.classList.remove((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Close));
                document.documentElement.style.setProperty("--sidebar-width", "300px");
            }
            window.addEventListener("resize", function() {
                if (window.innerWidth < 800) {
                    sidebarRef.current.classList.add((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Close));
                    sidebarRef.current.classList.remove((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open));
                    document.documentElement.style.setProperty("--sidebar-width", "100px");
                } else {
                    sidebarRef.current.classList.add((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open));
                    sidebarRef.current.classList.remove((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Close));
                    document.documentElement.style.setProperty("--sidebar-width", "300px");
                }
            });
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        ref: sidebarRef,
        className: [
            (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Sidebar),
            (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Open)
        ].join(" "),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Sidebar_Logo),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
                        icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_4__.faBars,
                        onClick: handleToggleSidebar
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            " ",
                            dashboardName,
                            " "
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: [
                    "list-unstyled"
                ].join(" "),
                children: SidebarItems.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: router.pathname == item.route ? (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Active) : "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: item.route,
                            passHref: true,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_7___default().Sidebar_Item_Inner),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_2__.FontAwesomeIcon, {
                                        icon: item.icon
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: item.displayName
                                    })
                                ]
                            })
                        })
                    }, index);
                })
            })
        ]
    });
};


/***/ })

};
;